package com.ey.springboot3security.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "pole")
public class Pole {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int poleid; 
	private String pole_material; 
	private Double pole_lat;
	private Double pole_lon;
	private String pole_remarks;
	
	public Pole() {
		
	}

	public Pole(int poleid, String pole_material, Double pole_lat, Double pole_lon, String pole_remarks) {
		super();
		this.poleid = poleid;
		this.pole_material = pole_material;
		this.pole_lat = pole_lat;
		this.pole_lon = pole_lon;
		this.pole_remarks = pole_remarks;
	}

	public int getPoleid() {
		return poleid;
	}

	public void setPoleid(int poleid) {
		this.poleid = poleid;
	}

	public String getPole_material() {
		return pole_material;
	}

	public void setPole_material(String pole_material) {
		this.pole_material = pole_material;
	}

	public Double getPole_lat() {
		return pole_lat;
	}

	public void setPole_lat(Double pole_lat) {
		this.pole_lat = pole_lat;
	}

	public Double getPole_lon() {
		return pole_lon;
	}

	public void setPole_lon(Double pole_lon) {
		this.pole_lon = pole_lon;
	}

	public String getPole_remarks() {
		return pole_remarks;
	}

	public void setPole_remarks(String pole_remarks) {
		this.pole_remarks = pole_remarks;
	}
	
	
}
