package com.ey.springboot3security.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ey.springboot3security.entity.Products;
import com.ey.springboot3security.repository.ProductsRepository;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class ProductsController {

	@Autowired
	private ProductsRepository productsRepository;
	
	//Create product
	@PostMapping("/createProduct")
	public Products createProduct(@RequestBody Products Products) {
		return productsRepository.save(Products);
	}
	
	// update product
	@PutMapping("/updateProduct/{id}")
	public ResponseEntity<Products> updateProduct(@PathVariable Integer id, @RequestBody Products prodDetails){
		
		Products prod = productsRepository.findById(id).get();
		prod.setProd_name(prodDetails.getProd_name());
		prod.setCatid(prodDetails.getCatid());
		prod.setProd_title(prodDetails.getProd_title());
		prod.setProd_desc(prodDetails.getProd_desc());
		prod.setProd_price(prodDetails.getProd_price());
		prod.setProd_image(prodDetails.getProd_image());
		
     	Products updateProduct = productsRepository.save(prod);
		return ResponseEntity.ok(updateProduct);
		
	}
		
	//Get All products
	@GetMapping("/getAllProducts")
	public List<Products> getAllProducts() {
		List<Products> products = productsRepository.findAll()
                .stream()
                .collect(Collectors.toList());
			return products ;
	}
	
	//Get single product
	@GetMapping("/product/{id}")
	public ResponseEntity<Optional<Products>> getProductsById(@PathVariable Integer id) {
		Optional<Products> product = productsRepository.findById(id);
		return ResponseEntity.ok(product);
	}
	
	//Delete product
	@DeleteMapping("/deleteProduct/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Integer id){
		Optional<Products> product = productsRepository.findById(id);
				
		productsRepository.deleteById(id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
}
