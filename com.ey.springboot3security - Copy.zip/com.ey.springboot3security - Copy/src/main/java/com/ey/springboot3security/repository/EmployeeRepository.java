package com.ey.springboot3security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ey.springboot3security.entity.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	
	//@Query("select a from Employee a join a.Address b where b.fk_emp_id = ?1")
    //public List<Employee> findAccountsByBranchCode(String branchCode);

    @Query("select a from Employee a join fetch a.address where a.empId = ?1")
    public Employee findEmpById(Long empId);
	
}
