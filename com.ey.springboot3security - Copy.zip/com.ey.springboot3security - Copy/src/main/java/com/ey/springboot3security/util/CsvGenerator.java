package com.ey.springboot3security.util;

import java.io.IOException;
import java.util.HashMap;
import java.lang.Iterable;
import java.util.List;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ey.springboot3security.entity.Laptop;


import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class CsvGenerator {

	//private List < Laptop > lapList;
	private HashMap<String, Object> lapList;
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;

    
	
	/*public  CsvGenerator(List < Laptop > lapList) {
        this.lapList = lapList;
        workbook = new XSSFWorkbook();
    }*/
    public CsvGenerator(HashMap<String, Object> data) {
		// TODO Auto-generated constructor stub
    	
    	this.lapList = data;
        workbook = new XSSFWorkbook();
	}
	private void writeHeader() {
        sheet = workbook.createSheet("Laptops");
        Row row = sheet.createRow(0);
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
        //createCell(row, 0, "ID", style);
        createCell(row, 0, "Name", style);
        createCell(row, 1, "Price", style);
        createCell(row, 2, "Ram", style);
        createCell(row, 3, "SSD", style);
    }
    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (valueOfCell instanceof Integer) {
            cell.setCellValue((Integer) valueOfCell);
        } else if (valueOfCell instanceof Long) {
            cell.setCellValue((Long) valueOfCell);
        } else if (valueOfCell instanceof String) {
            cell.setCellValue((String) valueOfCell);
        } else {
            cell.setCellValue((Double) valueOfCell);
        }
        cell.setCellStyle(style);
    }
    private void write() {
        int rowCount = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(14);
        style.setFont(font);
        System.out.println("lapList");
        System.out.println(lapList);
        //for (Laptop record: lapList) {
        for (HashMap.Entry<String,Object> record : lapList.entrySet()) {
        //for (HashMap<String, String> map : lapList) {
        	System.out.println("record");
            System.out.println(record);
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
            createCell(row, columnCount++, record.getValue(), style);
            createCell(row, columnCount++, record.getValue(), style);
            createCell(row, columnCount++, record.getValue(), style);
            createCell(row, columnCount++, record.getValue(), style);
        }
    }
    public void generateExcelFile(HttpServletResponse response) throws IOException {
        writeHeader();
        write();
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
}
