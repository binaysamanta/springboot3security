package com.ey.springboot3security.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.ey.springboot3security.entity.Laptop;
import com.ey.springboot3security.util.CsvGenerator;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.bind.JAXBException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api") 
@CrossOrigin("*")
public class GMLController {

@GetMapping("/gmlToExcel")
public void gmlToExcel(HttpServletResponse response) throws java.io.IOException, JAXBException  {
        

        String outputXLSXFile = "D:\\javaprojects\\upload_csv_excel\\coal_dep_2.xlsx";
        String inputGMLFile = "D:\\javaprojects\\coal_dep_2.gml";
        
        ArrayList<String> featureMember = new ArrayList<String>();
        ArrayList<String> fid = new ArrayList<String>();
        ArrayList<String> ogrId = new ArrayList<String>();
        ArrayList<String> ogrName = new ArrayList<String>();
        ArrayList<String> ogrLat = new ArrayList<String>();
        ArrayList<String> ogrLon = new ArrayList<String>();
        ArrayList<String> ogrAddress = new ArrayList<String>();
        ArrayList<Integer> ogrLatCount = new ArrayList<Integer>();
        
        Integer latCount = 0;
        
        try {

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new File(inputGMLFile));

            // normalize text representation
            doc.getDocumentElement().normalize();
            System.out.println("Root element of the doc is :\" "+ doc.getDocumentElement().getNodeName() + "\"");
            NodeList listOfFeature = doc.getElementsByTagName("ogr:Chennai_GML");
            int totalFeature = listOfFeature.getLength();
            System.out.println("Total no of Member : " + totalFeature);
            
            for(int i = 0; i <listOfFeature.getLength(); i++) {
                Node laptop = listOfFeature.item(i);
                if(laptop.getNodeType() == Node.ELEMENT_NODE) {

                    Element fidElement = (Element) laptop;
                    System.out.println("fid : "+ fidElement.getAttribute("fid"));
                    fid.add(fidElement.getAttribute("fid").trim());                  
                   
                }
            }
            
            for (int s = 0; s < listOfFeature.getLength(); s++) 
            {
                Node firstNode = listOfFeature.item(s);
                if (firstNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element firstOgrElement = (Element) firstNode;
                    
                    NodeList ogrIdList = firstOgrElement.getElementsByTagName("ogr:id");
                    Element ogrIdElement = (Element) ogrIdList.item(0);
                    NodeList textFNList = ogrIdElement.getChildNodes();
                    //System.out.println("ID : "+ ((Node) textFNList.item(0)).getNodeValue().trim());
                    ogrId.add(((Node) textFNList.item(0)).getNodeValue().trim());
                    
                    NodeList ogrNameList = firstOgrElement.getElementsByTagName("ogr:name");
                    Element ogrNameElement = (Element) ogrNameList.item(0);
                    NodeList textFNList1 = ogrNameElement.getChildNodes();
                    //System.out.println("Name : "+ ((Node) textFNList1.item(0)).getNodeValue().trim());
                    ogrName.add(((Node) textFNList1.item(0)).getNodeValue().trim());
                    
                    NodeList ogrLatList = firstOgrElement.getElementsByTagName("ogr:lat");
                    Element ogrLatElement = (Element) ogrLatList.item(0);
                    NodeList textFNList2 = ogrLatElement.getChildNodes();
                    //System.out.println("Lat : "+ ((Node) textFNList2.item(0)).getNodeValue().trim());
                    
                    if (ogrLat.contains( ((Node) textFNList2.item(0)).getNodeValue().trim()) ) {
                    	latCount +=1;
                    } else {
                    	latCount = latCount;
                    }
                    ogrLat.add(((Node) textFNList2.item(0)).getNodeValue().trim());
                    ogrLatCount.add(latCount);
                    
                    NodeList ogrLonList = firstOgrElement.getElementsByTagName("ogr:lon");
                    Element ogrLonElement = (Element) ogrLonList.item(0);
                    NodeList textFNList3 = ogrLonElement.getChildNodes();
                    //System.out.println("Lon : "+ ((Node) textFNList3.item(0)).getNodeValue().trim());
                    ogrLon.add(((Node) textFNList3.item(0)).getNodeValue().trim());
                    
                    NodeList ogrAddressList = firstOgrElement.getElementsByTagName("ogr:address");
                    Element ogrAddressElement = (Element) ogrAddressList.item(0);
                    NodeList textFNList4 = ogrAddressElement.getChildNodes();
                    //System.out.println("Address : "+ ((Node) textFNList4.item(0)).getNodeValue().trim());
                    ogrAddress.add(((Node) textFNList4.item(0)).getNodeValue().trim());
                    
                    
                }

            }
            
            
            for(String fId:fid)
            {
                System.out.println("fid : "+fid);
            }
            for(String ID:ogrId)
            {
                System.out.println("ID : "+ogrId);
            }
            /*for(String Name:ogrName)
            {
                System.out.println("name : "+ogrName);
            }
            for(String lat:ogrLat)
            {
                System.out.println("Lat : "+ogrLat);
            }
            for(String lon:ogrLon)
            {
                System.out.println("Lon : "+ogrLon);
            }
            for(String address:ogrAddress)
            {
                System.out.println("Address : "+ogrAddress);
            }*/
            

        } 
        catch (SAXParseException err) 
        {
            System.out.println("** Parsing error" + ", line "+ err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());
        } 
        catch (SAXException e) 
        {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();
        } 
        catch (Throwable t) 
        {
            t.printStackTrace();
        }
        
        //Export in excel
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Feature Collection");
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("fid");
        headerRow.createCell(1).setCellValue("ID");
        headerRow.createCell(2).setCellValue("Name");
        headerRow.createCell(3).setCellValue("Latitude");
        headerRow.createCell(4).setCellValue("Longitude");
        headerRow.createCell(5).setCellValue("Address");
        headerRow.createCell(6).setCellValue("Same Lat found");

        Map<String, Object[]> data = new HashMap<String, Object[]>();
        for(int i=0;i<fid.size();i++)
        {
            data.put(i+"",new Object[]{fid.get(i),ogrId.get(i),ogrName.get(i),ogrLat.get(i),ogrLon.get(i),ogrAddress.get(i),ogrLatCount.get(i)});
        }
        Set<String> keyset = data.keySet();
        int rownum = 1;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof Date)
                    cell.setCellValue((Date) obj);
                else if (obj instanceof Boolean)
                    cell.setCellValue((Boolean) obj);
                else if (obj instanceof String)
                    cell.setCellValue((String) obj);
                else if (obj instanceof Double)
                    cell.setCellValue((Double) obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer) obj);
            }
        }

        try {
            FileOutputStream out = new FileOutputStream(new File(outputXLSXFile));
            workbook.write(out);
            out.close();
            File f = new File(outputXLSXFile);
            String msg = "";
            if(f.exists() && !f.isDirectory()) { 
            	System.out.println("Excel written successfully..");
            	
            	try (InputStream inp = new FileInputStream(outputXLSXFile)) {
                    Workbook wb = WorkbookFactory.create(inp);

                    for (int i = 0; i < wb.getNumberOfSheets(); i++) {
                        System.out.println(wb.getSheetAt(i).getSheetName());
                        convertExcelToCSV(wb.getSheetAt(i), wb.getSheetAt(i).getSheetName());
                    }
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                } 
            	
            	 msg = "File has been created";
            	ResponseEntity.ok().body(msg);
            }else {
            	msg = "File creation failed";
            	ResponseEntity.ok().body(msg);
            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        
        
       

        
    }

	public void convertExcelToCSV(org.apache.poi.ss.usermodel.Sheet sheet, String sheetName) {
	    StringBuilder data = new StringBuilder();
	    try {
	        Iterator<Row> rowIterator = sheet.iterator();
	        while (rowIterator.hasNext()) {
	            Row row = rowIterator.next();
	            Iterator<Cell> cellIterator = row.cellIterator();
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	
	                CellType type = cell.getCellType();
	                if (type == CellType.BOOLEAN) {
	                    data.append(cell.getBooleanCellValue());
	                } else if (type == CellType.NUMERIC) {
	                    data.append(cell.getNumericCellValue());
	                } else if (type == CellType.STRING) {
	                    String cellValue = cell.getStringCellValue();
	                    if(!cellValue.isEmpty()) {
	                        cellValue = cellValue.replaceAll("\"", "\"\"");
	                        data.append("\"").append(cellValue).append("\"");
	                    }
	                } else if (type == CellType.BLANK) {
	                } else {
	                    data.append(cell + "");
	                }
	                if(cell.getColumnIndex() != row.getLastCellNum()-1) {
	                    data.append(",");
	                }
	            }
	            data.append('\n');
	        }
	        Files.write(Paths.get("D:\\javaprojects\\upload_csv_excel\\coal_dep_2.csv"),
	            data.toString().getBytes("UTF-8"));
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}
