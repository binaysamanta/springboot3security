package com.ey.springboot3security.controller;




import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.springboot3security.entity.Laptop;
import com.ey.springboot3security.entity.Pole;
import com.ey.springboot3security.entity.Student;
import com.ey.springboot3security.repository.PoleRepository;
import com.ey.springboot3security.util.CsvGenerator;
import com.ey.springboot3security.util.ExcelGenerator;

import io.jsonwebtoken.io.IOException;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


@RestController
@RequestMapping("/api") 
@CrossOrigin("*")
public class PoleController {

	@Autowired
	private PoleRepository PoleRepository; 
	
	
	
	//Create Pole
	@PostMapping("/createPole")
	public Pole createPole(@RequestBody Pole Pole) {
		return PoleRepository.save(Pole);
	}
	
	@GetMapping("/getPole") 
	public List<Pole> getPole() { 
	      List<Pole> pole = PoleRepository.findAll()
                  .stream()
                  .collect(Collectors.toList());
			//System.out.println(pole.toString());
			return pole ;
	} 
	
	@GetMapping("/pole/{id}")
	public ResponseEntity<Optional<Pole>> getPoleById(@PathVariable Integer id) {
		Optional<Pole> pole = PoleRepository.findById(id);
		return ResponseEntity.ok(pole);
	}
	
	@DeleteMapping("/deletePole/{id}")
	public ResponseEntity<Map<String, Boolean>> deletePole(@PathVariable Integer id){
		Optional<Pole> pole = PoleRepository.findById(id);
				
		
		PoleRepository.deleteById(id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	// update pole rest api
	@PutMapping("/updatePole/{id}")
	public ResponseEntity<Pole> updatePole(@PathVariable Integer id, @RequestBody Pole poleDetails){
		
		Pole pole = PoleRepository.findById(id).get();
		pole.setPole_material(poleDetails.getPole_material());
		pole.setPole_lat(poleDetails.getPole_lat());
		pole.setPole_lon(poleDetails.getPole_lon());
     	pole.setPole_remarks(poleDetails.getPole_remarks());
		
     	Pole updatedPole = PoleRepository.save(pole);
		return ResponseEntity.ok(updatedPole);
		
	}
	
	@GetMapping("/export-pole-excel")
    public void exportIntoExcelFile(HttpServletResponse response) throws IOException {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=pole" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);

        List <Pole> listOfPoles = PoleRepository.findAll();
        ExcelGenerator generator = new ExcelGenerator(listOfPoles);
        try {
			generator.generateExcelFile(response);
		} catch (java.io.IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	
	
	@GetMapping("/gmlToCSVLaptop")
    public void gmlToCSVLaptop(HttpServletResponse response) throws java.io.IOException, JAXBException  {
        
		String inputGMLFile = "D:\\javaprojects\\coal_dep_2.gml";
        String outputCSVFile = "D:\\javaprojects\\output.csv";
        
        String inputXMLFile = "D:\\javaprojects\\laptops.xml";
        
        /*
         * Get the Document Builder
         * Get Document
         * Normalize the xml structure
         * Get all the element by the tag name
         * */
        
        	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Get Document
            Document document = builder.parse(new File(inputXMLFile));
            // Normalize the xml structure
            document.getDocumentElement().normalize();
            // Get all the element by the tag name
            NodeList laptopList = document.getElementsByTagName("laptop");
            List<Laptop> listOfLaptop=new ArrayList<Laptop>();
            HashMap<String, Object> data = new HashMap<String, Object>();
            List<Map<String, Object>> myList = new ArrayList<>();
            for(int i = 0; i <laptopList.getLength(); i++) {
                Node laptop = laptopList.item(i);
                if(laptop.getNodeType() == Node.ELEMENT_NODE) {

                    Element laptopElement = (Element) laptop;
                    
                    
                    System.out.println("Laptop Name: " + laptopElement.getAttribute("name"));
                    
                    Laptop lapt = new Laptop();
                    //lapt.setName(laptopElement.getAttribute("name"));
                    data.put("name",laptopElement.getAttribute("name"));
                    
                    NodeList laptopDetails =  laptop.getChildNodes();
                    System.out.println(laptopDetails.getLength());
                    for(int j = 0; j < laptopDetails.getLength(); j++){
                        Node detail = laptopDetails.item(j);
                        if(detail.getNodeType() == Node.ELEMENT_NODE) {
                            Element detailElement = (Element) detail;
                            System.out.println("     " + detailElement.getTagName() + ": " + detailElement.getAttribute("price")+ ", " + detailElement.getAttribute("ram")+ ", " + detailElement.getAttribute("ssd"));
                            
                            //lapt.setPrice(detailElement.getAttribute("price"));
                            //lapt.setRam(detailElement.getAttribute("ram"));
                            //lapt.setSsd(detailElement.getAttribute("ssd"));
                            if(detailElement.getAttribute("price") !="") {
                            	data.put("price",detailElement.getAttribute("price"));
                            }
                            if(detailElement.getAttribute("ram") !="") {
                            	data.put("ram",detailElement.getAttribute("ram"));
                            }
                            if(detailElement.getAttribute("ssd") !="") {
                            	data.put("ssd",detailElement.getAttribute("ssd"));
                            }
                            
                            myList.add(data);  
                        }
                    } 
                    //listOfLaptop.addAll(data);
                    
                }
            }
            //data.putAll(data);
            //System.out.println(data);
            response.setContentType("application/octet-stream");
            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
            String currentDateTime = dateFormatter.format(new Date());

            String headerKey = "Content-Disposition";
            String headerValue = "attachment; filename=Laptops" + currentDateTime + ".xlsx";
            response.setHeader(headerKey, headerValue);

            //List <Pole> listOfPoles = PoleRepository.findAll();
            CsvGenerator generator = new CsvGenerator(data);
            try {
    			generator.generateExcelFile(response);
    		} catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        	

        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        
    }  
	
	
	@GetMapping("/gmlToCSVStudent")
    public void gmlToCSVStudent(HttpServletResponse response) throws java.io.IOException, JAXBException  {
        
		String inputGMLFile = "D:\\javaprojects\\coal_dep_2.gml";
        String outputCSVFile = "D:\\javaprojects\\output.csv";
        
        String inputXMLFile = "D:\\javaprojects\\student.xml";

        try {
		File file = new File(inputXMLFile);
		JAXBContext jaxbContext = JAXBContext.newInstance(Student.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		Student student = (Student) unmarshaller.unmarshal(file);
		System.out.println(student.getFirstName());

        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

        
    

    

}
