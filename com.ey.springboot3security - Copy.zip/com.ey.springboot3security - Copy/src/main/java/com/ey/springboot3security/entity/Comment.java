package com.ey.springboot3security.entity;

import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.*;

@Entity
@Transactional
@Table(name = "comments")
public class Comment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	//@Lob
	private String content;
	
	
	// getters and setters
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

}
