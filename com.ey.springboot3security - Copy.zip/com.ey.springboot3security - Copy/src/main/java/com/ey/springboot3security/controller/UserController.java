package com.ey.springboot3security.controller;

import com.ey.springboot3security.entity.AuthRequest; 
import com.ey.springboot3security.entity.UserInfo;
import com.ey.springboot3security.repository.UserInfoRepository;
import com.ey.springboot3security.service.JwtService;
import com.ey.springboot3security.service.UserInfoDetails;
import com.ey.springboot3security.service.UserInfoService;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize; 
import org.springframework.security.authentication.AuthenticationManager; 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; 
import org.springframework.security.core.Authentication; 
import org.springframework.security.core.userdetails.UsernameNotFoundException; 
import org.springframework.web.bind.annotation.*; 

@RestController
@RequestMapping("/auth") 
@CrossOrigin("*")
public class UserController { 

	@Autowired
	private UserInfoService service; 
	
	@Autowired
	private UserInfoRepository repository;

	@Autowired
	private JwtService jwtService; 

	@Autowired
	private AuthenticationManager authenticationManager; 

	@GetMapping("/welcome") 
	public String welcome() { 
		return "Welcome this endpoint is not secure"; 
	} 
	
	@GetMapping("/getUsers")
	public List<UserInfo> getUsers() {
		List<UserInfo> userInfo = repository.findAll()
				.stream().collect(Collectors.toList());
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> myList = new ArrayList<>();
		for(int i = 0; i <userInfo.size(); i++) {
			for(int j = 0; j < i; j++){
				
			}
		}
		
		return userInfo;
	}
	
	public boolean getUserExist(String username) {
		Optional<UserInfo> userDetail = repository.findByUsername(username); 
		//System.out.println("userDetail:-"+userDetail);
		if(userDetail.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}

	@PostMapping("/addNewUser") 
	public ResponseEntity<?> addNewUser(@RequestBody UserInfo userInfo) { 
			
		String username = userInfo.getUsername();
		boolean userExists = this.getUserExist(username);
		if (userExists) {
			Map<String, String> response = new HashMap<>();
			response.put("message", "User is exist!");
			//return ResponseEntity.ok(response);
			return new ResponseEntity(response,HttpStatus.FOUND);
		}else {
			return service.addUser(userInfo); 
		}
		
	} 
	
	@GetMapping("/current-user") 
	public UserInfoDetails getCurrentUser(Principal principal)
	{
		//return ((UserInfo)service.loadUserByUsername(principal.getName()));
		return ((UserInfoDetails)service.loadUserByUsername(principal.getName()));
	}

	@GetMapping("/user/userProfile") 
	@PreAuthorize("hasAuthority('ROLE_USERS')") 
	public String userProfile() { 
		return "Welcome to User Profile"; 
	} 

	@GetMapping("/admin/adminProfile") 
	@PreAuthorize("hasAuthority('ROLE_ADMIN')") 
	public String adminProfile() { 
		return "Welcome to Admin Profile"; 
	} 

	@PostMapping("/generateToken") 
	public ResponseEntity<?> authenticateAndGetToken(@RequestBody AuthRequest authRequest) { 
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())); 
		if (authentication.isAuthenticated()) { 
			//return jwtService.generateToken(authRequest.getUsername()); 
			String token = jwtService.generateToken(authRequest.getUsername()); 
			return ResponseEntity.ok(new JwtResponse(token));
		} else { 
			//throw new UsernameNotFoundException("invalid user request !"); 
			return ResponseEntity.ok("invalid user request !");
		} 
	} 

} 
