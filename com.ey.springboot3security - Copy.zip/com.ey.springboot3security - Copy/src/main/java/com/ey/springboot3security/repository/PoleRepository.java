package com.ey.springboot3security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ey.springboot3security.entity.Pole;
import com.ey.springboot3security.entity.UserInfo;

@Repository
public interface PoleRepository extends JpaRepository<Pole, Integer>{

}
