package com.ey.springboot3security.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.springboot3security.repository.EmployeeRepository;
import com.ey.springboot3security.entity.Employee;
import com.ey.springboot3security.entity.Pole;

@RestController
@RequestMapping("/api") 
@CrossOrigin("*")
public class EmployeeController {

	@Autowired
    private EmployeeRepository empRepository;

    @PostMapping("/saveEmployees")
    public ResponseEntity<String> saveEmployees(@RequestBody List<Employee> empData) {
    	System.out.println(empData);
        empRepository.saveAll(empData);
        return ResponseEntity.ok("Data saved");
    }

    @GetMapping("/getEmployees")
    public List<Employee> getEmployees(){
        return empRepository.findAll();
    }
    
    @GetMapping(path = "/employee/{id}")
    public Employee employee(@PathVariable("id") Long empId) {
        return empRepository.findEmpById(empId);
    }
	
	
	@DeleteMapping("/deleteEmployee/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteEmployee(@PathVariable Long Id){
		Optional<Employee> employee = empRepository.findById(Id);
		
		empRepository.deleteById(Id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/updateEmployee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee empDetails){
		
		Employee employee = empRepository.findById(id).get();
		employee.setEmpName(empDetails.getEmpName());
		employee.setEmpAge(empDetails.getEmpAge());
		
     	Employee updatedEmp = empRepository.save(employee);
		return ResponseEntity.ok(updatedEmp);
		
	}
}
