package com.ey.springboot3security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.springboot3security.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
	
	//Address findAddressById(Long addressId);
	
}
