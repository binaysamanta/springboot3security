package com.ey.springboot3security.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.ey.springboot3security.entity.Laptop;
import com.ey.springboot3security.util.CsvGenerator;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.bind.JAXBException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api") 
@CrossOrigin("*")
public class XMLController {

	@GetMapping("/xmlToExcel")
    public void xmlToExcel(HttpServletResponse response) throws java.io.IOException, JAXBException  {
        
		String inputGMLFile = "D:\\javaprojects\\coal_dep_2.gml";
        String outputXLSXFile = "D:\\javaprojects\\laptops.xlsx";
        String inputXMLFile = "D:\\javaprojects\\laptops.xml";
        
        ArrayList<String> lapname = new ArrayList<String>();
        ArrayList<String> price = new ArrayList<String>();
        ArrayList<String> ram = new ArrayList<String>();
        ArrayList<String> harddisk = new ArrayList<String>();
        
        try {

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new File(inputXMLFile));

            // normalize text representation
            doc.getDocumentElement().normalize();
            System.out.println("Root element of the doc is :\" "+ doc.getDocumentElement().getNodeName() + "\"");
            NodeList listOfLaptops = doc.getElementsByTagName("laptop");
            int totalPersons = listOfLaptops.getLength();
            System.out.println("Total no of Laptop : " + totalPersons);
            
            for(int i = 0; i <listOfLaptops.getLength(); i++) {
                Node laptop = listOfLaptops.item(i);
                if(laptop.getNodeType() == Node.ELEMENT_NODE) {

                    Element laptopElement = (Element) laptop;
                    System.out.println("LapName : "+ laptopElement.getAttribute("name"));
                    lapname.add(laptopElement.getAttribute("name").trim());                  
                   
                }
            }
            for (int s = 0; s < listOfLaptops.getLength(); s++) 
            {
                Node firstLaptopNode = listOfLaptops.item(s);
                if (firstLaptopNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element firstLaptopElement = (Element) firstLaptopNode;
                    NodeList priceList = firstLaptopElement.getElementsByTagName("price");
                    Element priceElement = (Element) priceList.item(0);
                    NodeList textFNList = priceElement.getChildNodes();
                    System.out.println("Price : "+ ((Node) textFNList.item(0)).getNodeValue().trim());
                    price.add(((Node) textFNList.item(0)).getNodeValue().trim());
                    
                    NodeList ramList = firstLaptopElement.getElementsByTagName("ram");
                    Element ramElement = (Element) ramList.item(0);
                    NodeList textLNList = ramElement.getChildNodes();
                    System.out.println("RAM : "+ ((Node) textLNList.item(0)).getNodeValue().trim());
                    ram.add(((Node) textLNList.item(0)).getNodeValue().trim());
                    
                    NodeList harddiskList = firstLaptopElement.getElementsByTagName("ssd");
                    Element harddiskElement = (Element) harddiskList.item(0);
                    NodeList textAgeList = harddiskElement.getChildNodes();
                    System.out.println("HardDisk : "+ ((Node) textAgeList.item(0)).getNodeValue().trim());
                    harddisk.add(((Node) textAgeList.item(0)).getNodeValue().trim());
                }// end of if clause

            }// end of for loop with s var
            
            for(String LapName:lapname)
            {
                System.out.println("LapName : "+lapname);
            }
            for(String Price:price)
            {
                System.out.println("price : "+price);
            }
            for(String Ram:ram)
            {
                System.out.println("ram : "+ram);
            }
            for(String Harddisk:harddisk)
            {
                System.out.println("harddisk : "+harddisk);
            }

        } 
        catch (SAXParseException err) 
        {
            System.out.println("** Parsing error" + ", line "+ err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());
        } 
        catch (SAXException e) 
        {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();
        } 
        catch (Throwable t) 
        {
            t.printStackTrace();
        }


        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Laptop Lists");
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Laptop Name");
        headerRow.createCell(1).setCellValue("Price");
        headerRow.createCell(2).setCellValue("RAM");
        headerRow.createCell(3).setCellValue("HardDisk");

        Map<String, Object[]> data = new HashMap<String, Object[]>();
        for(int i=0;i<price.size();i++)
        {
            data.put(i+"",new Object[]{lapname.get(i),price.get(i),ram.get(i),harddisk.get(i)});
        }
        Set<String> keyset = data.keySet();
        int rownum = 1;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof Date)
                    cell.setCellValue((Date) obj);
                else if (obj instanceof Boolean)
                    cell.setCellValue((Boolean) obj);
                else if (obj instanceof String)
                    cell.setCellValue((String) obj);
                else if (obj instanceof Double)
                    cell.setCellValue((Double) obj);
            }
        }

        try {
            FileOutputStream out = new FileOutputStream(new File(outputXLSXFile));
            workbook.write(out);
            out.close();
            File f = new File(outputXLSXFile);
            String msg = "";
            if(f.exists() && !f.isDirectory()) { 
            	System.out.println("Excel written successfully..");
            	 msg = "File has been created";
            	ResponseEntity.ok().body(msg);
            }else {
            	msg = "File creation failed";
            	ResponseEntity.ok().body(msg);
            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
       

        
    } 
}


